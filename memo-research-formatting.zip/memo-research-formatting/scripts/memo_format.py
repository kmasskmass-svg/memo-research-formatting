#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""مهارة ميمو: تطبيق تنسيق البحوث العلمية (نموذج جامعة الملك خالد) على ملف Word.
الاستعمال:
  python3 memo_format.py input.docx output.docx --title "عنوان البحث" [--no-auto-headings] [--front-pages N]
"""
import argparse, copy, re
import docx
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

AR = "Traditional Arabic"
EN = "Times New Roman"

# ---------- أدوات مساعدة ----------
def set_fonts(rpr_owner, cs=AR, latin=None, size=None, bold=None, underline=None):
    """rpr_owner: style.font أو run.font ؛ يضبط الخط العربي (cs) واللاتيني."""
    el = rpr_owner.element if hasattr(rpr_owner, "element") else rpr_owner
    rpr = el.get_or_add_rPr()
    rf = rpr.find(qn("w:rFonts"))
    if rf is None:
        rf = OxmlElement("w:rFonts"); rpr.insert(0, rf)
    for a in ("w:asciiTheme", "w:hAnsiTheme", "w:cstheme", "w:eastAsiaTheme"):
        if rf.get(qn(a)) is not None: del rf.attrib[qn(a)]
    lat = latin or cs
    rf.set(qn("w:ascii"), lat); rf.set(qn("w:hAnsi"), lat); rf.set(qn("w:cs"), cs)
    if size is not None:
        for tag in ("w:sz", "w:szCs"):
            e = rpr.find(qn(tag))
            if e is None: e = OxmlElement(tag); rpr.append(e)
            e.set(qn("w:val"), str(int(size * 2)))
    if bold is not None:
        for tag in ("w:b", "w:bCs"):
            e = rpr.find(qn(tag))
            if e is None: e = OxmlElement(tag); rpr.append(e)
            e.set(qn("w:val"), "1" if bold else "0")
    if underline is not None:
        e = rpr.find(qn("w:u"))
        if e is None: e = OxmlElement("w:u"); rpr.append(e)
        e.set(qn("w:val"), "single" if underline else "none")
    # احذف أي لون موروث لتبقى العناوين سوداء
    c = rpr.find(qn("w:color"))
    if c is not None: rpr.remove(c)

def set_bidi(ppr_owner, on=True):
    ppr = ppr_owner.get_or_add_pPr()
    b = ppr.find(qn("w:bidi"))
    if b is None:
        b = OxmlElement("w:bidi"); ppr.insert(0, b)
    b.set(qn("w:val"), "1" if on else "0")

def para_fmt(pf, align=None, before=0, after=0, line=1.15, first=None, hanging=None, keep=False):
    if align is not None: pf.alignment = align
    pf.space_before = Pt(before); pf.space_after = Pt(after)
    pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE; pf.line_spacing = line
    pf.left_indent = Cm(0); pf.right_indent = Cm(0)
    pf.first_line_indent = Cm(first) if first is not None else (Cm(-hanging) if hanging else Cm(0))
    if hanging: pf.right_indent = Cm(hanging)  # في RTL يكون "اليمين" بداية السطر
    pf.keep_with_next = keep

def get_style(doc, name, kind=1):
    try: return doc.styles[name]
    except KeyError: return doc.styles.add_style(name, kind)

# ---------- 1) إعداد الصفحة ----------
def page_setup(doc):
    for s in doc.sections:
        s.page_width, s.page_height = Cm(21.0), Cm(29.7)
        s.top_margin = Cm(2.5); s.bottom_margin = Cm(2.5)
        s.right_margin = Cm(3.5); s.left_margin = Cm(2.5)
        s.header_distance = Cm(1.25); s.footer_distance = Cm(1.25)
        sp = s._sectPr
        if sp.find(qn("w:bidi")) is None: sp.append(OxmlElement("w:bidi"))

# ---------- 2) الأنماط ----------
HEADINGS = {
    # المستوى: (الحجم، المحاذاة، قبل، بعد، تسطير)
    1: (20, WD_ALIGN_PARAGRAPH.CENTER, 18, 6, False),   # التمهيد/القسم/الفصل/المبحث/المقدمة/الخاتمة
    2: (18, WD_ALIGN_PARAGRAPH.CENTER, 12, 6, False),   # المطلب/المسألة
    3: (18, WD_ALIGN_PARAGRAPH.RIGHT, 8, 4, True),      # أولًا/ثانيًا وعناوين المقدمة الجانبية
    4: (16, WD_ALIGN_PARAGRAPH.RIGHT, 6, 2, False),     # الفروع
}

def styles(doc):
    n = doc.styles["Normal"]
    set_fonts(n.font, AR, EN, 16, bold=False)
    para_fmt(n.paragraph_format, WD_ALIGN_PARAGRAPH.JUSTIFY, 0, 0, 1.15, first=0)
    set_bidi(n.element)
    for lvl, (sz, al, b, a, u) in HEADINGS.items():
        st = get_style(doc, f"Heading {lvl}")
        set_fonts(st.font, AR, EN, sz, bold=True, underline=u)
        para_fmt(st.paragraph_format, al, b, a, 1.0, first=0, keep=True)
        set_bidi(st.element)
    fn = get_style(doc, "footnote text")
    set_fonts(fn.font, AR, EN, 14, bold=False)
    para_fmt(fn.paragraph_format, WD_ALIGN_PARAGRAPH.JUSTIFY, 0, 0, 1.0, hanging=0.5)
    set_bidi(fn.element)
    fr = get_style(doc, "footnote reference", 2)
    fr.font.superscript = True

# ---------- 3) العناوين التلقائية ----------
L1 = re.compile(r"^(التمهيد|المقدمة|الخاتمة|القسم\s|الفصل\s|الباب\s|فهرس|الفهارس|ثبت المصادر|المصادر والمراجع|المستخلص|مستخلص|الإهداء|شكر وتقدير|Abstract)")
L1b = re.compile(r"^المبحث\s")   # المبحث رأس مستوى 1 إن كان هو أعلى قسم بعد الفصل
L2 = re.compile(r"^(المطلب|المسألة|المسألتان)\s")
L3 = re.compile(r"^(أولًا|أولاً|ثانيًا|ثانياً|ثالثًا|ثالثاً|رابعًا|رابعاً|خامسًا|خامساً|سادسًا|سادساً|سابعًا|سابعاً|ثامنًا|ثامناً|تاسعًا|تاسعاً|عاشرًا|عاشراً)\s*[:：]")
INTRO_SIDE = re.compile(r"^(أهمية البحث|أهمية الموضوع|أسباب اختيار|مشكلة البحث|أسئلة البحث|أهداف البحث|حدود البحث|الدراسات السابقة|منهج البحث|إجراءات البحث|خطة البحث|النتائج|التوصيات)")

def auto_headings(doc):
    count = 0
    for p in doc.paragraphs:
        t = p.text.strip()
        if not t or len(t) > 120 or p.style.name.startswith("Heading"): continue
        lvl = None
        if L1.match(t) and len(t) < 60: lvl = 1
        elif L1b.match(t): lvl = 1
        elif L2.match(t): lvl = 2
        elif INTRO_SIDE.match(t) and len(t) < 50: lvl = 3
        elif L3.match(t) and len(t) < 70: lvl = 3
        if lvl:
            p.style = doc.styles[f"Heading {lvl}"]
            for r in p.runs:  # أزل التنسيق المباشر ليأخذ النمط
                rpr = r._r.rPr
                if rpr is not None:
                    for tag in ("w:sz", "w:szCs", "w:b", "w:bCs", "w:color", "w:u", "w:rFonts"):
                        for e in rpr.findall(qn(tag)): rpr.remove(e)
            count += 1
    return count

# ---------- 4) المتن ----------
QURAN_REF = re.compile(r"\[[^\[\]]{2,20}:\s*\d+(\s*[-–]\s*\d+)?\]")

def body(doc):
    for p in doc.paragraphs:
        if p.style.name.startswith("Heading") or p.style.name == "Title": continue
        txt = p.text
        latin = bool(re.search(r"[A-Za-z]{4,}", txt)) and not re.search(r"[؀-ۿ]", txt)
        for r in p.runs:
            rpr = r._r.rPr
            f = rpr.find(qn("w:rFonts")) if rpr is not None else None
            cur = f.get(qn("w:cs")) if f is not None else ""
            if cur and (cur.startswith("QCF") or "Quran" in cur or "Uthman" in cur or "HAFS" in cur):
                continue  # لا تمس خطوط المصحف
            if latin:
                set_fonts(r.font, EN, EN, 14)
            else:
                set_fonts(r.font, AR, EN, 11 if QURAN_REF.fullmatch(r.text.strip() or "x") else None)
            if rpr is not None:
                c = rpr.find(qn("w:color"))
                if c is not None and c.get(qn("w:val")) not in ("000000", "auto"): rpr.remove(c)
        if latin:
            set_bidi(p._p, False)
        pf = p.paragraph_format
        pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE; pf.line_spacing = 1.15
        if p.alignment in (None, WD_ALIGN_PARAGRAPH.LEFT, WD_ALIGN_PARAGRAPH.RIGHT) and len(txt) > 90:
            p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    # الجداول (الفهارس): خط 14 مفرد
    for tb in doc.tables:
        for row in tb.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    p.paragraph_format.line_spacing = 1.0
                    for r in p.runs: set_fonts(r.font, AR, EN, 14)

# ---------- 5) الحواشي ----------
def footnotes(doc):
    # ترقيم يبدأ من جديد في كل صفحة
    st = doc.settings.element
    fp = st.find(qn("w:footnotePr"))
    if fp is None:
        fp = OxmlElement("w:footnotePr"); st.append(fp)
    nr = fp.find(qn("w:numRestart"))
    if nr is None:
        nr = OxmlElement("w:numRestart"); fp.insert(0, nr)
    nr.set(qn("w:val"), "eachPage")
    for s in doc.sections:  # إعداد القسم يغلب إعدادات المستند
        sfp = s._sectPr.find(qn("w:footnotePr"))
        if sfp is not None: s._sectPr.remove(sfp)
    # أقواس حول رقم الحاشية في المتن
    wrap_refs(doc.element.body, "w:footnoteReference", superscript=True)
    part = None
    for rel in doc.part.rels.values():
        if rel.reltype.endswith("/footnotes"): part = rel.target_part
    if part is not None:
        from lxml import etree
        root = etree.fromstring(part.blob)
        wrap_refs(root, "w:footnoteRef", superscript=False)
        for p in root.iter(qn("w:p")):
            ppr = p.find(qn("w:pPr"))
            if ppr is None: ppr = OxmlElement("w:pPr"); p.insert(0, ppr)
            ps = ppr.find(qn("w:pStyle"))
            if ps is None: ps = OxmlElement("w:pStyle"); ppr.insert(0, ps)
            ps.set(qn("w:val"), doc.styles["footnote text"].style_id)
            for r in p.iter(qn("w:r")):
                rpr = r.find(qn("w:rPr"))
                if rpr is None: continue
                for tag in ("w:sz", "w:szCs"):
                    for e in rpr.findall(qn(tag)): rpr.remove(e)
        part._blob = etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)
        if hasattr(part, "_element"): part._element = root

def _run_text(r):
    return "".join(t.text or "" for t in r.iter(qn("w:t"))) if r is not None else ""

def wrap_refs(root, tag, superscript):
    for ref in list(root.iter(qn(tag))):
        run = ref.getparent()
        prev, nxt = run.getprevious(), run.getnext()
        if _run_text(prev).endswith("(") and _run_text(nxt).startswith(")"): continue
        for side, ch in (("before", "("), ("after", ")")):
            nr = OxmlElement("w:r")
            rpr = copy.deepcopy(run.find(qn("w:rPr"))) if run.find(qn("w:rPr")) is not None else OxmlElement("w:rPr")
            for e in rpr.findall(qn("w:rStyle")): rpr.remove(e)
            if superscript:
                va = rpr.find(qn("w:vertAlign"))
                if va is None: va = OxmlElement("w:vertAlign"); rpr.append(va)
                va.set(qn("w:val"), "superscript")
            nr.append(rpr)
            t = OxmlElement("w:t"); t.text = ch; nr.append(t)
            (run.addprevious if side == "before" else run.addnext)(nr)
        if not superscript:  # رقم الحاشية أسفل الصفحة بحجم النص لا مرتفع
            rpr = run.find(qn("w:rPr"))
            if rpr is None: rpr = OxmlElement("w:rPr"); run.insert(0, rpr)
            for e in rpr.findall(qn("w:rStyle")): rpr.remove(e)

# ---------- 6) الترويسة والتذييل ----------
def bottom_border(p):
    ppr = p._p.get_or_add_pPr()
    b = OxmlElement("w:pBdr"); bt = OxmlElement("w:bottom")
    for k, v in (("w:val", "single"), ("w:sz", "8"), ("w:space", "1"), ("w:color", "000000")): bt.set(qn(k), v)
    b.append(bt); ppr.append(b)

def add_field(p, instr, size=16):
    def r(kind, text=None):
        run = p.add_run(); set_fonts(run.font, AR, EN, size, bold=True)
        if kind == "fld":
            e = OxmlElement("w:fldChar"); e.set(qn("w:fldCharType"), text); run._r.append(e)
        elif kind == "ins":
            e = OxmlElement("w:instrText"); e.set(qn("xml:space"), "preserve"); e.text = text; run._r.append(e)
        else:
            run.text = text
    r("fld", "begin"); r("ins", f" {instr} "); r("fld", "separate"); r("txt", "1"); r("fld", "end")

def chapter_name_of(section_index, doc):
    """أول عنوان من المستوى 1 داخل القسم يُستعمل اسمًا له في الترويسة."""
    idx = 0
    for el in doc.element.body.iterchildren():
        if el.tag == qn("w:p"):
            p = docx.text.paragraph.Paragraph(el, doc)
            if idx == section_index and p.style.name == "Heading 1" and p.text.strip():
                return p.text.strip().split(":")[0][:25]
            if el.find(".//" + qn("w:sectPr")) is not None: idx += 1
    return ""

def header_footer(doc, title, front_pages, keep_hf=True):
    secs = doc.sections
    def _has_hdr(s):
        h = s.header
        return any(p.text.strip() for p in h.paragraphs) or h._element.find(".//" + qn("w:drawing")) is not None
    def _has_pg(s):
        return "PAGE" in "".join(t.text or "" for t in s.footer._element.iter(qn("w:instrText")))
    pre = [(_has_hdr(s), _has_pg(s)) for s in secs]   # الحالة قبل أي تعديل
    for i, s in enumerate(secs):
        s.different_first_page_header_footer = (i == 0 and front_pages > 0)
        hdr = s.header
        has_hdr, has_pg = pre[i]
        if keep_hf and has_hdr: hdr = None
        if hdr is not None:
          hdr.is_linked_to_previous = False
          for p in list(hdr.paragraphs)[1:]: p._p.getparent().remove(p._p)
          hp = hdr.paragraphs[0]
          for r in list(hp.runs): r._r.getparent().remove(r._r)
          set_bidi(hp._p); hp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
          hp.paragraph_format.tab_stops.add_tab_stop(Cm(15.0), alignment=2)  # يسار السطر
          r = hp.add_run(title); set_fonts(r.font, AR, EN, 12, bold=True)
          name = chapter_name_of(i, doc)
          if name:
              r = hp.add_run("\t" + name); set_fonts(r.font, AR, EN, 13, bold=True)
          bottom_border(hp)
        if keep_hf and has_pg: continue
        ftr = s.footer; ftr.is_linked_to_previous = False
        fp = ftr.paragraphs[0]
        for r in list(fp.runs): r._r.getparent().remove(r._r)
        fp.alignment = WD_ALIGN_PARAGRAPH.CENTER; set_bidi(fp._p)
        add_field(fp, "PAGE", 14)
    # ترقيم: الصفحات التمهيدية بالحروف (أ، ب، ت...) والمتن بالأرقام من 1
    if front_pages and len(secs) > 1:
        def pgnum(s, fmt=None, start=None):
            sp = s._sectPr; e = sp.find(qn("w:pgNumType"))
            if e is None: e = OxmlElement("w:pgNumType"); sp.append(e)
            if fmt: e.set(qn("w:fmt"), fmt)
            if start: e.set(qn("w:start"), str(start))
        pgnum(secs[0], "arabicAlpha", 1)
        pgnum(secs[min(front_pages, len(secs) - 1)], "decimal", 1)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("inp"); ap.add_argument("out")
    ap.add_argument("--title", default="")
    ap.add_argument("--no-auto-headings", action="store_true")
    ap.add_argument("--replace-header-footer", action="store_true",
                    help="استبدال الترويسة والتذييل الموجودين (الافتراضي: الإبقاء عليهما إن وُجدا)")
    ap.add_argument("--front-pages", type=int, default=0,
                    help="عدد الأقسام (Sections) التمهيدية التي تُرقَّم بالحروف قبل المقدمة")
    a = ap.parse_args()
    doc = docx.Document(a.inp)
    page_setup(doc); styles(doc)
    n = 0 if a.no_auto_headings else auto_headings(doc)
    body(doc); footnotes(doc)
    header_footer(doc, a.title or (doc.core_properties.title or ""), a.front_pages, keep_hf=not a.replace_header_footer)
    doc.save(a.out)
    print(f"تم. عناوين مكتشفة: {n}، أقسام: {len(doc.sections)}، حواشٍ وأقواسها: مضبوطة.")

if __name__ == "__main__":
    main()
