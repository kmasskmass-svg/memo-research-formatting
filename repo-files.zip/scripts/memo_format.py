#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""مهارة ميمو: تنسيق البحوث والرسائل العلمية وفق دليل الجامعة المختارة.
الاستعمال:
  python3 memo_format.py --list
  python3 memo_format.py input.docx output.docx --title "عنوان البحث" [--university kku]
        [--profile-file my.json] [--line 1.5] [--no-auto-headings] [--front-pages N]
        [--replace-header-footer]
الجامعة الافتراضية: kku (جامعة الملك خالد).
"""
import argparse, copy, json, os, re, sys
import docx
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_UNI = "kku"
ALIGN = {"center": WD_ALIGN_PARAGRAPH.CENTER, "right": WD_ALIGN_PARAGRAPH.RIGHT,
         "left": WD_ALIGN_PARAGRAPH.LEFT, "justify": WD_ALIGN_PARAGRAPH.JUSTIFY}
P = {}  # مواصفات الجامعة المختارة

def load_profiles():
    with open(os.path.join(HERE, "universities.json"), encoding="utf-8") as f:
        data = json.load(f)
    return {k: v for k, v in data.items() if not k.startswith("_")}

# ---------- أدوات مساعدة ----------
def set_fonts(rpr_owner, cs=None, latin=None, size=None, bold=None, underline=None):
    """rpr_owner: style.font أو run.font ؛ يضبط الخط العربي (cs) واللاتيني."""
    cs = cs or P["font"]
    el = rpr_owner.element if hasattr(rpr_owner, "element") else rpr_owner
    rpr = el.get_or_add_rPr()
    rf = rpr.find(qn("w:rFonts"))
    if rf is None:
        rf = OxmlElement("w:rFonts"); rpr.insert(0, rf)
    for a in ("w:asciiTheme", "w:hAnsiTheme", "w:cstheme", "w:eastAsiaTheme"):
        if rf.get(qn(a)) is not None: del rf.attrib[qn(a)]
    lat = latin or P.get("english_font", "Times New Roman")
    rf.set(qn("w:ascii"), lat); rf.set(qn("w:hAnsi"), lat); rf.set(qn("w:cs"), cs)
    if size is not None:
        for tag in ("w:sz", "w:szCs"):
            e = rpr.find(qn(tag))
            if e is None: e = OxmlElement(tag); rpr.append(e)
            e.set(qn("w:val"), str(int(round(size * 2))))
    if bold is not None:
        for tag in ("w:b", "w:bCs"):
            e = rpr.find(qn(tag))
            if e is None: e = OxmlElement(tag); rpr.append(e)
            e.set(qn("w:val"), "1" if bold else "0")
    if underline is not None:
        e = rpr.find(qn("w:u"))
        if e is None: e = OxmlElement("w:u"); rpr.append(e)
        e.set(qn("w:val"), "single" if underline else "none")
    c = rpr.find(qn("w:color"))  # العناوين والمتن بالأسود
    if c is not None: rpr.remove(c)

def set_bidi(ppr_owner, on=True):
    ppr = ppr_owner.get_or_add_pPr()
    b = ppr.find(qn("w:bidi"))
    if b is None:
        b = OxmlElement("w:bidi"); ppr.insert(0, b)
    b.set(qn("w:val"), "1" if on else "0")

def apply_spacing(pf, kind="body"):
    """kind: body أو footnote أو heading"""
    if kind == "heading":
        pf.line_spacing_rule = WD_LINE_SPACING.SINGLE; return
    exact = P.get("exact_pt") if kind == "body" else P.get("footnote_exact_pt")
    if exact:
        pf.line_spacing_rule = WD_LINE_SPACING.EXACTLY; pf.line_spacing = Pt(exact)
    else:
        v = P.get("line", 1.15) if kind == "body" else P.get("footnote_line", 1.0)
        pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE; pf.line_spacing = v

def para_fmt(pf, align=None, before=0, after=0, kind="body", first=None, hanging=None, keep=False):
    if align is not None: pf.alignment = align
    pf.space_before = Pt(before); pf.space_after = Pt(after)
    apply_spacing(pf, kind)
    pf.left_indent = Cm(0); pf.right_indent = Cm(0)
    pf.first_line_indent = Cm(first) if first is not None else (Cm(-hanging) if hanging else Cm(0))
    if hanging: pf.right_indent = Cm(hanging)  # في RTL يكون "اليمين" بداية السطر
    pf.keep_with_next = keep

def get_style(doc, name, kind=1):
    try: return doc.styles[name]
    except KeyError: return doc.styles.add_style(name, kind)

# ---------- 1) إعداد الصفحة ----------
def page_setup(doc):
    m = P["margins"]
    for s in doc.sections:
        s.page_width, s.page_height = Cm(21.0), Cm(29.7)
        s.top_margin = Cm(m["top"]); s.bottom_margin = Cm(m["bottom"])
        s.right_margin = Cm(m["right"]); s.left_margin = Cm(m["left"])
        s.header_distance = Cm(P.get("header_distance", 1.25))
        s.footer_distance = Cm(P.get("footer_distance", 1.25))
        sp = s._sectPr
        if sp.find(qn("w:bidi")) is None: sp.append(OxmlElement("w:bidi"))

# ---------- 2) الأنماط ----------
def styles(doc):
    n = doc.styles["Normal"]
    set_fonts(n.font, size=P["body"], bold=False)
    para_fmt(n.paragraph_format, WD_ALIGN_PARAGRAPH.JUSTIFY, 0, P.get("para_after", 0), "body", first=0)
    set_bidi(n.element)
    spacing = {1: (18, 6), 2: (12, 6), 3: (8, 4), 4: (6, 2)}
    for lvl in (1, 2, 3, 4):
        sz, al, bold, und = P[f"h{lvl}"]
        st = get_style(doc, f"Heading {lvl}")
        set_fonts(st.font, size=sz, bold=bold, underline=und)
        b, a = spacing[lvl]
        para_fmt(st.paragraph_format, ALIGN[al], b, a, "heading", first=0, keep=True)
        set_bidi(st.element)
    fn = get_style(doc, "footnote text")
    set_fonts(fn.font, size=P["footnote"], bold=False)
    para_fmt(fn.paragraph_format, WD_ALIGN_PARAGRAPH.JUSTIFY, 0, 0, "footnote", hanging=0.5)
    set_bidi(fn.element)
    fr = get_style(doc, "footnote reference", 2)
    fr.font.superscript = True

# ---------- 3) العناوين التلقائية ----------
L1 = re.compile(r"^(التمهيد|المقدمة|الخاتمة|القسم\s|الفصل\s|الباب\s|فهرس|الفهارس|ثبت المصادر|المصادر والمراجع|قائمة المصادر|قائمة المراجع|المستخلص|مستخلص|الإهداء|شكر وتقدير|Abstract)")
L1b = re.compile(r"^المبحث\s")
L2 = re.compile(r"^(المطلب|المسألة|المسألتان)\s")
L3 = re.compile(r"^(أولًا|أولاً|ثانيًا|ثانياً|ثالثًا|ثالثاً|رابعًا|رابعاً|خامسًا|خامساً|سادسًا|سادساً|سابعًا|سابعاً|ثامنًا|ثامناً|تاسعًا|تاسعاً|عاشرًا|عاشراً)\s*[:：]")
INTRO_SIDE = re.compile(r"^(أهمية البحث|أهمية الموضوع|أسباب اختيار|مشكلة البحث|أسئلة البحث|أهداف البحث|حدود البحث|الدراسات السابقة|منهج البحث|إجراءات البحث|خطة البحث|النتائج|التوصيات)")

def auto_headings(doc):
    count = 0
    for p in doc.paragraphs:
        t = p.text.strip()
        if not t or len(t) > 120 or p.style.name.startswith("Heading"): continue
        lvl = None
        if L1.match(t) and len(t) < 60: lvl = 1
        elif L1b.match(t): lvl = 1
        elif L2.match(t): lvl = 2
        elif INTRO_SIDE.match(t) and len(t) < 50: lvl = 3
        elif L3.match(t) and len(t) < 70: lvl = 3
        if lvl:
            p.style = doc.styles[f"Heading {lvl}"]
            for r in p.runs:  # أزل التنسيق المباشر ليأخذ النمط
                rpr = r._r.rPr
                if rpr is not None:
                    for tag in ("w:sz", "w:szCs", "w:b", "w:bCs", "w:color", "w:u", "w:rFonts"):
                        for e in rpr.findall(qn(tag)): rpr.remove(e)
            count += 1
    return count

# ---------- 4) المتن ----------
QURAN_REF = re.compile(r"\[[^\[\]]{2,20}:\s*\d+(\s*[-–]\s*\d+)?\]")
QURAN_FONT = ("QCF", "Quran", "Uthman", "HAFS", "KFGQPC", "Mushaf")

def body(doc):
    indent = P.get("first_indent", 0)
    for p in doc.paragraphs:
        if p.style.name.startswith("Heading") or p.style.name == "Title": continue
        txt = p.text
        latin = bool(re.search(r"[A-Za-z]{4,}", txt)) and not re.search(r"[؀-ۿ]", txt)
        for r in p.runs:
            rpr = r._r.rPr
            f = rpr.find(qn("w:rFonts")) if rpr is not None else None
            cur = (f.get(qn("w:cs")) or "") if f is not None else ""
            if any(k in cur for k in QURAN_FONT):
                continue  # لا تمس خطوط المصحف
            if latin:
                en = P.get("english_font", "Times New Roman")
                set_fonts(r.font, en, en, P.get("english_size", 14))
            else:
                is_ref = QURAN_REF.fullmatch(r.text.strip() or "x")
                set_fonts(r.font, size=P["quran_ref"] if is_ref else None)
        if latin:
            set_bidi(p._p, False)
        pf = p.paragraph_format
        apply_spacing(pf, "body")
        long_para = len(txt) > 90
        if p.alignment in (None, WD_ALIGN_PARAGRAPH.LEFT, WD_ALIGN_PARAGRAPH.RIGHT) and long_para:
            p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        numbered = p._p.pPr is not None and p._p.pPr.find(qn("w:numPr")) is not None
        if indent and long_para and not numbered and p.alignment == WD_ALIGN_PARAGRAPH.JUSTIFY:
            pf.first_line_indent = Cm(indent)
    for tb in doc.tables:  # الجداول والفهارس
        for row in tb.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
                    p.paragraph_format.first_line_indent = Cm(0)
                    for r in p.runs:
                        rpr = r._r.rPr
                        f = rpr.find(qn("w:rFonts")) if rpr is not None else None
                        cur = (f.get(qn("w:cs")) or "") if f is not None else ""
                        if any(k in cur for k in QURAN_FONT): continue
                        set_fonts(r.font, size=min(14, P["body"]))

# ---------- 5) الحواشي ----------
def footnotes(doc):
    st = doc.settings.element
    fp = st.find(qn("w:footnotePr"))
    if fp is None:
        fp = OxmlElement("w:footnotePr"); st.append(fp)
    nr = fp.find(qn("w:numRestart"))
    if nr is None:
        nr = OxmlElement("w:numRestart"); fp.insert(0, nr)
    nr.set(qn("w:val"), P.get("footnote_restart", "eachPage"))
    for s in doc.sections:  # إعداد القسم يغلب إعدادات المستند
        sfp = s._sectPr.find(qn("w:footnotePr"))
        if sfp is not None: s._sectPr.remove(sfp)
    parens = P.get("footnote_parens", True)
    if parens:
        wrap_refs(doc.element.body, "w:footnoteReference", superscript=True)
    part = None
    for rel in doc.part.rels.values():
        if rel.reltype.endswith("/footnotes"): part = rel.target_part
    if part is None: return
    from lxml import etree
    root = etree.fromstring(part.blob)
    if parens:
        wrap_refs(root, "w:footnoteRef", superscript=False)
    sid = doc.styles["footnote text"].style_id
    for p in root.iter(qn("w:p")):
        ppr = p.find(qn("w:pPr"))
        if ppr is None: ppr = OxmlElement("w:pPr"); p.insert(0, ppr)
        ps = ppr.find(qn("w:pStyle"))
        if ps is None: ps = OxmlElement("w:pStyle"); ppr.insert(0, ps)
        ps.set(qn("w:val"), sid)
        for tag in ("w:spacing", "w:ind"):  # التباعد والإزاحة من النمط
            for e in ppr.findall(qn(tag)): ppr.remove(e)
        for r in p.iter(qn("w:r")):
            rpr = r.find(qn("w:rPr"))
            if rpr is None: continue
            rf = rpr.find(qn("w:rFonts"))
            cur = (rf.get(qn("w:cs")) or "") if rf is not None else ""
            if any(k in cur for k in QURAN_FONT): continue
            for tag in ("w:sz", "w:szCs"):
                for e in rpr.findall(qn(tag)): rpr.remove(e)
            if rf is not None and not re.search(r"Times|Arial|Calibri", cur):
                rpr.remove(rf)  # يأخذ خط الحاشية من النمط
    part._blob = etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)
    if hasattr(part, "_element"): part._element = root

def _run_text(r):
    return "".join(t.text or "" for t in r.iter(qn("w:t"))) if r is not None else ""

def wrap_refs(root, tag, superscript):
    for ref in list(root.iter(qn(tag))):
        run = ref.getparent()
        prev, nxt = run.getprevious(), run.getnext()
        if _run_text(prev).endswith("(") and _run_text(nxt).startswith(")"): continue
        for side, ch in (("before", "("), ("after", ")")):
            nr = OxmlElement("w:r")
            rpr = copy.deepcopy(run.find(qn("w:rPr"))) if run.find(qn("w:rPr")) is not None else OxmlElement("w:rPr")
            for e in rpr.findall(qn("w:rStyle")): rpr.remove(e)
            if superscript:
                va = rpr.find(qn("w:vertAlign"))
                if va is None: va = OxmlElement("w:vertAlign"); rpr.append(va)
                va.set(qn("w:val"), "superscript")
            nr.append(rpr)
            t = OxmlElement("w:t"); t.text = ch; nr.append(t)
            (run.addprevious if side == "before" else run.addnext)(nr)
        if not superscript:  # رقم الحاشية أسفل الصفحة بحجم النص لا مرتفع
            rpr = run.find(qn("w:rPr"))
            if rpr is None: rpr = OxmlElement("w:rPr"); run.insert(0, rpr)
            for e in rpr.findall(qn("w:rStyle")): rpr.remove(e)

# ---------- 6) الترويسة والتذييل ----------
def bottom_border(p):
    ppr = p._p.get_or_add_pPr()
    b = OxmlElement("w:pBdr"); bt = OxmlElement("w:bottom")
    for k, v in (("w:val", "single"), ("w:sz", "8"), ("w:space", "1"), ("w:color", "000000")): bt.set(qn(k), v)
    b.append(bt); ppr.append(b)

def add_page_field(p, size, parens=False):
    def r(kind, text=None):
        run = p.add_run(); set_fonts(run.font, size=size, bold=False)
        if kind == "fld":
            e = OxmlElement("w:fldChar"); e.set(qn("w:fldCharType"), text); run._r.append(e)
        elif kind == "ins":
            e = OxmlElement("w:instrText"); e.set(qn("xml:space"), "preserve"); e.text = text; run._r.append(e)
        else:
            run.text = text
    if parens: r("txt", "(")
    r("fld", "begin"); r("ins", " PAGE "); r("fld", "separate"); r("txt", "1"); r("fld", "end")
    if parens: r("txt", ")")

def chapter_name_of(section_index, doc):
    """أول عنوان من المستوى 1 داخل القسم يُستعمل اسمًا له في الترويسة."""
    idx = 0
    for el in doc.element.body.iterchildren():
        if el.tag == qn("w:p"):
            p = docx.text.paragraph.Paragraph(el, doc)
            if idx == section_index and p.style.name == "Heading 1" and p.text.strip():
                return p.text.strip().split(":")[0][:25]
            if el.find(".//" + qn("w:sectPr")) is not None: idx += 1
    return ""

def _clear(part):
    """يفرغ الترويسة/التذييل تمامًا (نصوص وأشكال وجداول) ويُبقي فقرة واحدة."""
    el = part._element
    paras = el.findall(qn("w:p"))
    keep = paras[0] if paras else None
    for child in list(el):
        if child is not keep: el.remove(child)
    if keep is None:
        keep = OxmlElement("w:p"); el.append(keep)
    for child in list(keep):
        if child.tag != qn("w:pPr"): keep.remove(child)
    return part.paragraphs[0]

def header_footer(doc, title, front_pages, keep_hf=True):
    secs = doc.sections
    def _has_hdr(s):
        h = s.header
        return any(p.text.strip() for p in h.paragraphs) or h._element.find(".//" + qn("w:drawing")) is not None
    def _has_pg(s):
        x = "".join(t.text or "" for t in s.footer._element.iter(qn("w:instrText")))
        x += "".join(t.text or "" for t in s.header._element.iter(qn("w:instrText")))
        return "PAGE" in x
    pre = [(_has_hdr(s), _has_pg(s)) for s in secs]   # الحالة قبل أي تعديل
    top = P.get("page_number", "bottom-center") == "top-left"
    pn_size = P.get("page_number_size", 14)
    pn_parens = P.get("page_number_parens", False)
    for i, s in enumerate(secs):
        s.different_first_page_header_footer = (i == 0 and front_pages > 0)
        has_hdr, has_pg = pre[i]
        hp = None
        if not (keep_hf and has_hdr):
            hdr = s.header; hdr.is_linked_to_previous = False
            hp = _clear(hdr)
            set_bidi(hp._p); hp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            hp.paragraph_format.tab_stops.add_tab_stop(
                Cm(21.0 - P["margins"]["right"] - P["margins"]["left"]), alignment=2)
            if P.get("header", False) and title:
                r = hp.add_run(title); set_fonts(r.font, size=12, bold=True)
                name = chapter_name_of(i, doc)
                if name and not top:
                    r = hp.add_run("\t" + name); set_fonts(r.font, size=13, bold=True)
                bottom_border(hp)
        if keep_hf and has_pg:
            continue
        if top:
            if hp is None: continue  # ترويسة الباحث محفوظة؛ لا نضيف إليها
            ftr = s.footer; ftr.is_linked_to_previous = False; _clear(ftr)
            hp.add_run("\t")
            add_page_field(hp, pn_size, pn_parens)
        else:
            ftr = s.footer; ftr.is_linked_to_previous = False
            fp = _clear(ftr)
            fp.alignment = WD_ALIGN_PARAGRAPH.CENTER; set_bidi(fp._p)
            add_page_field(fp, pn_size, pn_parens)
    if front_pages and len(secs) > 1:
        def pgnum(s, fmt=None, start=None):
            sp = s._sectPr; e = sp.find(qn("w:pgNumType"))
            if e is None: e = OxmlElement("w:pgNumType"); sp.append(e)
            if fmt: e.set(qn("w:fmt"), fmt)
            if start: e.set(qn("w:start"), str(start))
        pgnum(secs[0], P.get("front_numbering", "arabicAlpha"), 1)
        pgnum(secs[min(front_pages, len(secs) - 1)], "decimal", 1)

def list_profiles(profiles):
    print("الجامعات المتاحة (الافتراضية: kku):")
    for k, v in profiles.items():
        mark = " ← الافتراضية" if k == DEFAULT_UNI else ""
        print(f"  {k:6s} {v['name']}: {v['font']} {v['body']}، حواشٍ {v['footnote']}{mark}")

def main():
    ap = argparse.ArgumentParser(description="مهارة ميمو لتنسيق البحوث العلمية")
    ap.add_argument("inp", nargs="?"); ap.add_argument("out", nargs="?")
    ap.add_argument("--university", "-u", default=DEFAULT_UNI, help="رمز الجامعة (انظر --list)")
    ap.add_argument("--profile-file", help="ملف JSON بمواصفات جامعة غير مدرجة")
    ap.add_argument("--list", action="store_true", help="عرض الجامعات المتاحة")
    ap.add_argument("--title", default="")
    ap.add_argument("--line", type=float, help="تباعد أسطر المتن بدل قيمة الجامعة")
    ap.add_argument("--body-size", type=float, help="مقاس خط المتن بدل قيمة الجامعة")
    ap.add_argument("--no-auto-headings", action="store_true")
    ap.add_argument("--replace-header-footer", action="store_true",
                    help="استبدال الترويسة والتذييل الموجودين (الافتراضي: الإبقاء عليهما)")
    ap.add_argument("--front-pages", type=int, default=0,
                    help="عدد الأقسام (Sections) التمهيدية التي تُرقَّم بالحروف قبل المقدمة")
    a = ap.parse_args()
    profiles = load_profiles()
    if a.list:
        list_profiles(profiles); return
    if not (a.inp and a.out):
        ap.error("حدد ملف الإدخال وملف الإخراج")
    global P
    if a.profile_file:
        base = dict(profiles[DEFAULT_UNI]); base.update(notes="", source="ملف مواصفات خاص")
        with open(a.profile_file, encoding="utf-8") as f: base.update(json.load(f))
        P = base
    else:
        if a.university not in profiles:
            print(f"الجامعة «{a.university}» غير مدرجة."); list_profiles(profiles); sys.exit(1)
        P = dict(profiles[a.university])
    if a.line:
        P["line"] = a.line; P.pop("exact_pt", None)
    if a.body_size: P["body"] = a.body_size
    doc = docx.Document(a.inp)
    page_setup(doc); styles(doc)
    n = 0 if a.no_auto_headings else auto_headings(doc)
    body(doc); footnotes(doc)
    header_footer(doc, a.title or (doc.core_properties.title or ""), a.front_pages,
                  keep_hf=not a.replace_header_footer)
    doc.save(a.out)
    print(f"تم التنسيق وفق: {P['name']}. عناوين مكتشفة: {n}، أقسام: {len(doc.sections)}.")
    if P.get("notes"): print("ملاحظة:", P["notes"])

if __name__ == "__main__":
    main()
